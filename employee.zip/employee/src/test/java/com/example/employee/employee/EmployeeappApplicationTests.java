package com.example.employee.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeappApplicationTests {

	@Test
	void contextLoads() {
	}

}
